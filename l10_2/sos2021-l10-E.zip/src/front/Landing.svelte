
<main>
	<h2>Landing Page</h2>
	<a href="#/contacts">Contacts Manager</a>
</main>

